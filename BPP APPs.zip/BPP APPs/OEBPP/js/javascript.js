$(document).on('click','[nombreObjetValidation]', function(){
  // Définir le nombre d'objets
	if($('[nombreObjet]').val() <=0 || $('[nombreObjet]').val() == ""){alert('Erreur ! m doit être entier non nul .'); return(false);}

 // Définir la taille des boites
	 if($('[capaciteBoite]').val() <=0 || $('[capaciteBoite]').val() == ""){alert('Erreur ! W doit être entier non nul'); return(false);}

	 var taille = [2, 3, 5];
	 var demande = [2, 3, 3];



	$('[wDiv]').html("");
	$('[bDiv]').html("");

	for( i= 1; i<=parseInt($('[nombreObjet]').val()) ;i++){
		var w = document.createElement('INPUT');
		var b = document.createElement('INPUT');
		w.setAttribute('type','number');
		b.setAttribute('type','number');
		w.setAttribute('min','1');
		b.setAttribute('min','1');
		w.setAttribute('placeholder','Taille objet '+i);
		b.setAttribute('placeholder','Demande objet '+i);
		w.setAttribute('class','form-control inputWandB');
		b.setAttribute('class','form-control inputWandB');
		w.setAttribute('name','W'+i);
		b.setAttribute('name','B'+i);
		w.setAttribute('value', taille[i-1]);
		b.setAttribute('value', demande[i-1]);
		$('[notice1]').attr('style','')
	  $('[wDiv]').append(w);
		$('[bDiv]').append(b);
	}

})

// Affichage fichier data.text syntaxe GLPK

$(document).on('click','[afficher]', function(){

	G = buildGraph1(buildGraph());
	var A = G[1];
	var V = G[0];
	$('[textarea]').attr('style','"width:100%;  cursor: text;   max-height: 400px;        overflow-x: hidden;      overflow-y: auto;      padding: 10px 8px 6px;');

	fichier_lp = '';
	variables = 'Generals  \n';
	fonction_obj = 'Minimize \n obj: +z';
	contraintes = 'Subject To  \n';
	demandes = ' ';

	for(i=1; i <= parseInt($('[nombreobjet]').val()) ; i++){

		demandes= demandes + 'demand(' +i+ '): ' ;
		Bvar = parseInt($('[name=B'+i+']').val());
		Wvar = parseInt($('[name=W'+i+']').val());

		for(j=0; j<A.length; j++){
			if(A[j][2] == i)
			demandes= demandes + '+ f('+ A[j][0] + ',' + A[j][1] +  ',' + i + ') ';
		}
			demandes = demandes + '>= '+Bvar+'\n ' ;


	}

	for(j=0; j<(A.length); j++){
		variables = variables + ' f('+ A[j][0] + ',' + A[j][1] + ',' +A[j][2]+ ') \n';
		//fonction_obj = fonction_obj + '+ f('+ A[j][0] + ',' + A[j][1] + ',' +A[j][2]+ ')' ;
	 }

	noeudS = 'node('+V[0]+'):';
	noeudT = ' node('+V[V.length-1]+'):';

	noeudM = '';

	for(i=0;i<V.length;i++){
		var k = i+1;
		console.log("v["+i+"]= " +V[i] );
		for(j=0; j<A.length; j++){
			// noeud source
				if(i == 0 && A[j][0] == 0)
					noeudS = noeudS + ' - f(' +A[j][0]+ ',' +A[j][1]+ ',' +A[j][2]+ ')' ;

		 // noeud au milieu
			//  if(A[j][0] == V[3] || A[j][1] == V[3] ){
				//	nnnM = nnnM + ' - f(' +A[j][0]+ ',' +A[j][1]+ ',' +A[j][2]+ ')' ;
				//}


		 // noeud puit
				if(i == V.length-1  && A[j][1] == V[V.length-1]){
					noeudT = noeudT + ' + f(' +A[j][0]+ ',' +A[j][1]+ ',' +A[j][2]+ ')' ;
					console.log('ici nnf2 + f(' +A[j][0]+ ',' +A[j][1]+ ',' +A[j][2]+ ')');
					}
		 }
	}
	noeudS = noeudS + ' + z = -0 \n' ;

	noeudT = noeudT + ' - z = -0' ;

	for(z=1;z<V.length-1;z++){
		noeudM = noeudM + ' node('+V[z]+'):';

					for(j=0; j<A.length; j++){

				 // noeud au milieu
						if(A[j][0] == V[z]){
							noeudM = noeudM + ' - f(' +A[j][0]+ ',' +A[j][1]+ ',' +A[j][2]+ ')' ;
						}
						else if(A[j][1] == V[z]){
							noeudM = noeudM + ' + f(' +A[j][0]+ ',' +A[j][1]+ ',' +A[j][2]+ ')' ;
						}

					}
					noeudM = noeudM + '= 0 \n'  ;

		}


	nnn2 = noeudS + noeudM ;

	fichier_lp= fonction_obj+' \n'+contraintes+' '+noeudS + noeudM + noeudT+'\n'+demandes+ ' \n' +variables+  '\nEND' ;

	console.log(fichier_lp);


	//resultatf =   run();
	//var chaine = resultatf[0][2];


 	afficherV3(buildGraph1(buildGraph()), Z = run());
	$('[affresult]').attr('style','');




})

// Affichage résultat final
$(document).on('click','[affresult]', function(){

	var B = new Array();
	for(i=1; i <= parseInt($('[nombreobjet]').val()) ; i++){
		B.push(parseInt($('[name=B'+i+']').val()));
	}
	G = buildGraphe3(buildGraphe2(),B);



	titre = '<h2> Les rangements optimaux : </h>'
	$('[t]').html($('[t]').html()+titre);

	for(i=0; i<G.length ;i++){

		F = G[i][0];
		I = G[i][1];
		table = '<table  class="table-striped browserref " v2table="" style="margin:50px"> <tbody class="browBody"> <tr v2tr="">';
		table = table+'<td>'+F+' boite(s) avec les articles: (index objet[sa taille]) : </td>';





		for(x=0; x < I.length ;x++){
				table = table+	'<td>'+I[x][0]+' [ '+ parseInt($('[name=W'+I[x][0]+']').val()) +  ' ] </td>';
		}

		table = table+'</tr></tbody></table>';

		$('[resultcontainer]').html($('[resultcontainer]').html()+table);

	}

})


function run(){
    var F = new Array();
		var E = new  Array();
		var S = new Array([]);

		 start = new Date();
     logNode.innerText = "";
		var lp = glp_create_prob();
		glp_read_lp_from_string(lp, null, fichier_lp);

		glp_scale_prob(lp, GLP_SF_AUTO);

		var smcp = new SMCP({presolve: GLP_ON});
		glp_simplex(lp, smcp);

		var iocp = new IOCP({presolve: GLP_ON});
		glp_intopt(lp, iocp);

		log("Le nombre de boite optimal est égal à : " + glp_mip_obj_val(lp) + " boites." );
		for(var i = 1; i <= glp_get_num_cols(lp); i++){
				log(glp_get_col_name(lp, i)  + " = " + glp_mip_col_val(lp, i));
        F[i-1] = glp_get_col_name(lp, i) ;
				E[i-1] = glp_mip_col_val(lp, i);
		}

		S[0] = F ;
		S[1] = E ;
		return S;
}
// Algorithme de construction du graphe
function buildGraph(){

			var V = new Array();
			var A = new Array();
			V.push("T");
			V.push(0);


			for(i=1; i <= parseInt($('[nombreobjet]').val()) ; i++){

				var T = new Array();

				for(o=1; o < V.length; o++){

					var a = parseInt(V[o]);
					var somme = 0;
					console.log("a : "+a);
					for(z=i; z <= parseInt($('[nombreobjet]').val()); z++){
					somme = somme + (parseInt($('[name=B'+z+']').val()) * parseInt($('[name=W'+z+']').val()));
					}





					for(k=1; k<= parseInt($('[name=B'+i+']').val()) ; k++){

						a2 = parseInt(a) + parseInt($('[name=W'+i+']').val());

						if(a2 >= parseInt($('[capaciteboite]').val())){

						var TEMP = new Array ();
						TEMP[0] = parseInt(a);
						TEMP[1] = "T";
						TEMP[2] = i;
						A.push(TEMP);
						break;

						}else{

							var TEMP = new Array ();
						TEMP[0] = parseInt(a);
						TEMP[1] = parseInt(a2);
						TEMP[2] = i;
						A.push(TEMP);
						}




						if( V.indexOf(parseInt(a2)) != -1){ break};
						T.push(parseInt(a2));
						a=parseInt(a2);

					}

				}
			//V.push(T);
				for(p=0;p < T.length ; p++){
					V.push(parseInt(T[p]));
				}

			}
			var G = new Array([]);
			G[0] = V;
			G[1] = A;
		return G;

}

// ajout des acrs LOSS
function buildGraph1(G){


	var A = G[1];
	var V = G[0];

	for(i=0; i < V.length; i++){

		if( parseInt(V[i]) !=0){
		var TEMP = new Array();
		TEMP[0] = V[i];
		//TEMP[1] = parseInt($('[capaciteboite]').val())+1;
		TEMP[1] = "T";
		TEMP[2] = 0;
		A.push(TEMP);

		}



	}
  V.sort()
//	V.push(parseInt($('[capaciteboite]').val())+1);
//	V.push("T");

	var RST = new Array();
	RST[0] = V;
	RST[1] = A;

	return(RST);
}

function afficherV3(G, Z){
	//var Z = new Array([]);
  FF0 = Z[0];
	FF1 = Z[1];
	V = G[0];
	A = G[1];

//affichage ensemble des sommets
$('[VTR]').html('')
var vertex = document.createElement('H3')
vertex.innerHTML = "Ensemble des sommets "
$('[VTR]').append(vertex)

	var vTd = document.createElement('TD');

	for(i=0; i<V.length; i++){

		var td = document.createElement('TD');
		td.innerHTML = V[i];
		$('[v2Tr]').append(td);


	}


	$('[v2Table]').attr('style','');

	$('[ATR]').html('')
	var arc = document.createElement('H3')
	arc.innerHTML = "Ensemble des arcs du graphe "
	$('[ATR]').append(arc)



	$('[a2Tr]').html('<tr><th style="text-align: center">Sommet départ</th>  <th style="text-align: center">Sommet arrivée </th>  <th style="text-align: center">i-ème objet </th> <th style="text-align: center">Flots</th> </tr>');
  //var FF = [3,1,0,0,1,1,3,0,0,0,1];
	for(i=0; i<A.length ; i++){


	var btn = document.createElement('input');
  btn.setAttribute('type','number') ;
  //btn.setAttribute('placeholder','Flot '+(parseInt(i+1)));
  btn.setAttribute('class','form-control inputWandB');

//	for(j=1; j<FF1.length; j++){
	// if(A[i][0]==FF0[j].charAt(2)  && A[i][1]==FF0[j].charAt(4) )
	 //btn.setAttribute('value', FF1[j]);
	// }
	//var td4 = document.createElement('TD');
	btn.setAttribute('name','F'+(parseInt(i+1)));

//	var tr = document.createElement('TR');

	//var td1 = document.createElement('TD');

	//td1.innerHTML = Z[0][i+1].charAt(2);
	//var td2 = document.createElement('TD');
	//td2.innerHTML = Z[0][i+1].charAt(4);

	//var td3 = document.createElement('TD');
	//td4.setAttribute('name', 'F'+(parseInt(i+1)));
	//td4.setAttribute('style','width:100px');
	//td3.innerHTML = Z[0][i+1].charAt(6);
	//td4.appendChild(btn);
	//td4.innerHTML = Z[1][i+1];

	  var tr = document.createElement('TR');

		var td1 = document.createElement('TD');
		td1.innerHTML = A[i][0];
		//td1.innerHTML = Z[0][i+1].charAt(2);

		var td2 = document.createElement('TD');
		td2.innerHTML = A[i][1];
    //td2.innerHTML = Z[0][i+1].charAt(4);

		var td3 = document.createElement('TD');
		var td4 = document.createElement('TD');

		td4.setAttribute('style','width:100px')
	  td3.innerHTML = A[i][2];
		//td3.innerHTML = Z[0][i+1].charAt(6);
		td4.appendChild(btn);
		//btn.setAttribute('value', FF1[i+1]);
		for(j=1; j<FF1.length; j++){
			 if(A[i][0]==FF0[j].charAt(2)  && A[i][1]==FF0[j].charAt(4) && A[i][2]==FF0[j].charAt(6)  ) {
			 btn.setAttribute('value', FF1[j]);
			 //console.log( "condition"+j+ " : "  +A[i][0]+ "  == " +FF0[j].charAt(2)+ " et "  +A[i][1]+ " == " + FF0[j].charAt(4)  + "et" + A[i][2] + " == " +FF0[j].charAt(6)+  "  le flot  = " +FF1[j] );
		 }
			 }

		$(tr).append(td1);
		$(tr).append(td2);
		$(tr).append(td3);
		$(tr).append(td4);

	$('[a2Tr]').append(tr);

}
$('[a2Table]').attr('style','');

}


// Algorithme d'extraction de la solution
function buildGraphe2(){

	G = buildGraph1(buildGraph());
	var A = G[1];
	var V = G[0];

	var adj = new Array();

	var L = new Array();


	for(i=0; i < A.length ; i++){

		if(parseInt($('[name=F'+(i+1)+']').val()) > 0){

		   var TEMP = new Array();
		   TEMP[0] = parseInt(A[i][0]);
		   TEMP[1] = A[i][1];
		   TEMP[2] = parseInt(A[i][2]);
		   TEMP[3] = parseInt($('[name=F'+parseInt((i+1))+']').val());
		   adj.push(TEMP);
		}

	}


	var lst = new Array();
	INDICE = 0;
	for(j=0; j < (V.length) ; j++){
	MAX = 0;

	for(i=0; i < (V.length) ; i++){
		if(MAX < parseInt(V[i])){
			MAX = parseInt(V[i]);
			INDICE = i;
		}
	}

	V[INDICE] = parseInt(V[j]);
	V[j] = 0;
	lst.push(MAX);
	}





	var DPU = new Array();
	var BEST = new Array();

			var TEMP = new Array();
			TEMP[0] = "T";
			TEMP[1] = 9999;
			DPU.push(TEMP);

			var TEMP = new Array();
			TEMP[0] = "T";
			TEMP[1] = "NIL";
			TEMP[2] = "NIL";
			BEST.push(TEMP);

	while(true){
		for(i=0; i < lst.length; i++){

			var TEMP = new Array();
			TEMP[0] = lst[i];
			TEMP[1] = 0;
			DPU.push(TEMP);

			var TEMP = new Array();
			TEMP[0] = lst[i];
			TEMP[1] = "NIL";
			TEMP[2] = "NIL";
			BEST.push(TEMP);

			for(j=0; j < adj.length; j++){

				if(adj[j][0] == lst[i]){
					var varV = adj[j][1];
					var varI = adj[j][2];
					var varF = adj[j][3];
					var varU = adj[j][0];
					for(o=0;o < DPU.length; o++){
						if(varV== DPU[o][0]){
						var	dpv = DPU[o][1];
						}
					}

					if(dpv < varF){
						 m = dpv;
					}else{
						 m = varF;
					}

					for(o=0;o < DPU.length; o++){
						if(varU== DPU[o][0]){
						dpu = DPU[o][1];
						}
					}

					if(m > dpu){
					for(o=0;o < DPU.length; o++){
						if(varU == DPU[o][0]){
							DPU[o][1] = m;
						}
					}
					for(o=0;o < BEST.length; o++){
						if(varU == BEST[o][0]){
							BEST[o][1] = varV;
							BEST[o][2] = varI;
						}
					}
					}


				}

			}
			}

					for(o=0;o < DPU.length; o++){
						if(0 == DPU[o][0]){
						 f = DPU[o][1];
						}
					}
		if(f == 0) break;

		var u = 0;

		var patern = new Array();

		while(u != "NIL"){

			for(o=0;o < BEST.length; o++){
						if(u == BEST[o][0]){
							varV = BEST[o][1];
							varI = BEST[o][2];
						}
			}


			for(o=0;o < adj.length; o++){
				if(u == adj[o][0] && varV == adj[o][1] && varI == adj[o][2]){
					adj[o][3] = adj[o][3] - f;
				}
			}
     	if(varI != 0 && varI != "NIL"){
				patern.push(varI);
			}
			u = varV;

		}

		var TEMP = new Array();
			TEMP[0] = f;
			TEMP[1] = patern;

			L.push(TEMP);


		}


	return L;


}



// Algorithme de supression d'excès de demande
function buildGraphe3(L,B){
var LP = new Array();

	for(i=0; i < L.length ; i++ ){
		var F = L[i][0];
		var patern = L[i][1];


		var C = new Array();

		for(m=0; m < patern.length ;m++){
			var TEMP = new Array();
			TEMP[0] = patern[m];
			TEMP[1] = 0;
			C.push(TEMP);
		}

		for(m=0; m < patern.length ;m++){

			for(n=0; n < C.length ;n++){

				if(C[n][0] == patern[m]){

					if(parseInt(C[n][1] + 1) > B[parseInt(patern[m]) - 1]){
						C[n][1] = B[parseInt(patern[m]) - 1];
					}else{
						C[n][1] = parseInt(C[n][1]) + 1;
					}

				}

			}


		}

			var c = new Array();
			var TEMP = new Array();
			TEMP[0] = C[0][0];
			TEMP[1] = C[0][1];
			c.push(TEMP);

			for(n=0; n < C.length ;n++){
				test = false;
				for(m=0; m < c.length ;m++){

					if(c[m][0] == C[n][0]){
						test = true;
					}

				}

				if(test != true){
					var TEMP = new Array();
					TEMP[0] = C[n][0];
					TEMP[1] = C[n][1];
					c.push(TEMP);
				}


			}

			while(F > 0){

			paterno = new Array();



			for(n=0; n < c.length ;n++){

				for(m=0; m < patern.length ;m++){

					if(c[n][0] == patern[m] && parseInt(c[n][1]) > 0){
					var TEMP = new Array();
					TEMP[0] = parseInt(patern[m]); //i
					TEMP[1] = c[n][1]; //ci
					TEMP[2] = parseInt(patern[m] * c[n][1]); //ci * i
					paterno.push(TEMP);

				}

			}
			}

			var biDIVci = new Array();
			for(n=0; n < paterno.length ;n++){

				var bi = B[parseInt((paterno[n][0])-1)];
				var cim = parseInt(paterno[n][1]);
				biDIVci.push(parseInt(bi / cim));




			}

			var minBiCi = biDIVci[0];
			for(n=0; n < biDIVci.length  ;n++){


				if(minBiCi > biDIVci[n]){
					minBiCi	= biDIVci[n];
				}

			}

			if(F < minBiCi){
				newF = F;
			}else{
				newF = minBiCi;
			}

			if(newF != 0){
				var TEMP = new Array();
				TEMP[0] = newF; //i
				TEMP[1] = paterno; //ci
				LP.push(TEMP);

			}


			for(n=0; n < paterno.length ;n++){

				var BI = B[parseInt((paterno[n][0])-1)];
				B[parseInt((paterno[n][0])-1)] =  BI - newF;

				for(m=0; m < c.length ;m++){
					if(c[m][0] == paterno[n][0]){
						var CI = paterno[n][1];

						if(CI > BI){ c[m][1] = BI;


								   }


					}
				}



			}


			F = F - newF;
		}

	}
	return LP;
}
